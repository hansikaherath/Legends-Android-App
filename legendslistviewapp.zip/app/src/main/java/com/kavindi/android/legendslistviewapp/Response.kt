package com.kavindi.android.legendslistviewapp

class Response<T> {

}
