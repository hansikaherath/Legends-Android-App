package com.kavindi.android.legendslistviewapp.posts.Aapi;

public @interface GET {
}
