package com.kavindi.android.legendslistviewapp

class GsonConverterFactory {

}
